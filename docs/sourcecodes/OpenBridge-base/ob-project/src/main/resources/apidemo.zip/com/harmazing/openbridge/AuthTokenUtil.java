package com.harmazing.openbridge;

import java.util.Date;

import com.alibaba.fastjson.JSONObject;

public class AuthTokenUtil {
	/**
	 * 应用的票据信息
	 */
	private static AuthToken authToken = null;

	/**
	 * 鉴权服务基础地址(外部导入服务，可以将此配置放在配置文件中读取；开发型服务此配置可以初始化在配置文件中，或直接初始化在此文件)
	 */
//	private static final String authUrl = "http://openbridge.f3322.net:88/api/auth/getToken.do";

	/**
	 * 调用api的应用标识，
	 * 如果应用是app,该值为mod_app的app_id,
	 * 如果应用是api服务，该值为mod_service表中的service_id，
	 * 如果应用是第三方应用，该值为mod_external_app的id
	 */
//	private static final String appId = "70milmlmlj6cg2z2cwpffcetv8netr7";

	/**
	 * 调用api的应用类型
	 * 如果应用是app，该值为app，
	 * 如果应用是api服务，该值为api，
	 * 如果应用是第三方应用，该值为external
	 */
//	private static final String appType = "app";
	
	/**
	 * 调用api的应用secureKey
	 * 如果应用是app,该值为mod_app的secure_key,
	 * 如果应用是api服务，该值为mod_service表中的secure_key，
	 * 如果应用是第三方应用，该值为mod_external_app的secure_key
	 */
//	private static final String appSecure = "70neil8b2yvjx9wuuagvetqdcgn7zjp";

	private synchronized static void requestToken(String authUrl,String appId,String appSecure) {
		String tokenMesssage = RestUtil.get(authUrl+"?appId=" + appId + "&appType=app&appSecure=" + appSecure);
		JSONObject resultRest = JSONObject.parseObject(tokenMesssage);
		if (resultRest != null && "200".equals(resultRest.get("code").toString())) {
			JSONObject data = resultRest.getJSONObject("data");
			authToken = new AuthToken();
			authToken.setAuthToken(data.getString("auth-token"));
			authToken.setAuthAppId(data.getString("auth-appId"));
			authToken.setRequestTime(new Date());
		}
	}

	public static AuthToken getToken(String authUrl,String appId,String appSecure) {
		// 如果token为空着请求Token
		if (authToken == null) {
			requestToken(authUrl,appId,appSecure);
		}
		// 如果token获取时间大于20分钟重新请求
		if ((System.currentTimeMillis() - authToken.getRequestTime().getTime()) > 1000 * 60 * 20) {
			synchronized (authToken) {
				requestToken(authUrl,appId,appSecure);
			}
		}
		return authToken;
	}
}
